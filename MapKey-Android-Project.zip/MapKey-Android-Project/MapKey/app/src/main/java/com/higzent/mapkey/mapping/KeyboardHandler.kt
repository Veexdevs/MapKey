package com.higzent.mapkey.mapping

import android.view.InputDevice
import android.view.KeyEvent
import com.higzent.mapkey.model.KeyCatalog
import com.higzent.mapkey.model.KeyOption

/**
 * Responsável por detectar eventos de teclado físico usando as APIs
 * oficiais do Android (android.view.KeyEvent / dispatchKeyEvent).
 *
 * Quando um teclado físico (USB ou Bluetooth) está conectado, o próprio
 * Android já entrega os KeyEvent normalmente para a Activity/View em foco
 * através de dispatchKeyEvent()/onKeyDown(). Não existe uma API separada e
 * "escondida" para "detectar teclado conectado" além de consultar
 * InputDevice — por isso este handler expõe:
 *
 * 1. [isPhysicalKeyboard] para verificar se o evento realmente veio de um
 *    teclado físico (e não do teclado virtual na tela, que gera eventos
 *    de outra fonte).
 * 2. [handleKeyEvent] para transformar o KeyEvent recebido em um
 *    [KeyOption] do catálogo do MapKey, usado pelo editor para preencher
 *    automaticamente a tecla pressionada.
 *
 * Este handler NÃO injeta eventos em outros aplicativos — ele apenas
 * observa e traduz eventos que o próprio sistema já entrega ao MapKey
 * enquanto o app está em primeiro plano ou em foco.
 */
class KeyboardHandler {

    interface Listener {
        fun onPhysicalKeyDetected(option: KeyOption)
        fun onUnknownKeyDetected(keyCode: Int, keyLabel: String)
    }

    var listener: Listener? = null

    fun isPhysicalKeyboard(event: KeyEvent): Boolean {
        val device = InputDevice.getDevice(event.deviceId) ?: return false
        return device.sources and InputDevice.SOURCE_KEYBOARD == InputDevice.SOURCE_KEYBOARD &&
            device.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
    }

    /**
     * Deve ser chamado a partir de dispatchKeyEvent() ou onKeyDown() da
     * Activity/View que está capturando o teclado (ex.: EditorActivity
     * enquanto o diálogo de seleção de tecla está aberto).
     *
     * Retorna true se o evento foi tratado (consumido) pelo handler.
     */
    fun handleKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false
        if (!isPhysicalKeyboard(event)) return false

        val option = KeyCatalog.findByKeyCode(event.keyCode)
        if (option != null) {
            listener?.onPhysicalKeyDetected(option)
        } else {
            val label = KeyEvent.keyCodeToString(event.keyCode)
                .removePrefix("KEYCODE_")
            listener?.onUnknownKeyDetected(event.keyCode, label)
        }
        return true
    }
}
