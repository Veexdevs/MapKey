package com.higzent.mapkey.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.higzent.mapkey.MapKeyApplication
import com.higzent.mapkey.R
import com.higzent.mapkey.mapping.MappingPointView
import com.higzent.mapkey.model.Mapping
import com.higzent.mapkey.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Serviço em primeiro plano responsável por desenhar os botões de
 * mapeamento como um overlay sobre outros aplicativos, usando
 * WindowManager com o tipo de janela oficial TYPE_APPLICATION_OVERLAY
 * (API pública, disponível a partir do Android 8 / API 26 — por isso o
 * minSdk do projeto é 26).
 *
 * LIMITAÇÃO IMPORTANTE:
 * Este overlay é uma camada visual de REFERÊNCIA/CONTROLE por cima do
 * jogo. Tocar em um botão do overlay dispara o callback local do MapKey
 * (ex.: vibração, log, ou — quando o AccessibilityService estiver
 * habilitado pelo usuário — um gesto sintético via dispatchGesture()).
 * O Android não permite, através de APIs públicas, que um app injete
 * eventos de KeyEvent diretamente no processo de outro aplicativo. Ou
 * seja: o MapKey não consegue "apertar W" dentro do jogo de forma
 * transparente sem que o próprio jogo, ou o sistema, ofereça esse canal.
 * Esta arquitetura deixa o ponto de extensão pronto
 * (MapKeyAccessibilityService) para quando o usuário habilitar o serviço
 * de acessibilidade manualmente.
 */
class OverlayMappingService : Service() {

    private lateinit var windowManager: WindowManager
    private val overlayViews = mutableListOf<MappingPointView>()
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private var profileId: String? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        profileId = intent?.getStringExtra(EXTRA_PROFILE_ID)
        startForeground(NOTIFICATION_ID, buildNotification())

        if (!Settings.canDrawOverlays(this)) {
            // Sem a permissão de overlay concedida pelo usuário, o
            // WindowManager rejeita a adição da view. Interrompemos aqui
            // de forma segura em vez de deixar o app falhar silenciosamente.
            stopSelf()
            return START_NOT_STICKY
        }

        profileId?.let { loadAndDrawMappings(it) }

        return START_STICKY
    }

    private fun loadAndDrawMappings(profileId: String) {
        val app = application as MapKeyApplication
        serviceScope.launch {
            val mappings = app.mappingManager.getMappings(profileId)
            mappings.forEach { addOverlayPoint(it) }
        }
    }

    private fun addOverlayPoint(mapping: Mapping) {
        val displayMetrics = resources.displayMetrics
        val pointView = MappingPointView(this, mapping, editable = true)

        val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = (mapping.x * displayMetrics.widthPixels).toInt()
        params.y = (mapping.y * displayMetrics.heightPixels).toInt()

        pointView.parentWidthPx = displayMetrics.widthPixels
        pointView.parentHeightPx = displayMetrics.heightPixels

        pointView.listener = object : MappingPointView.Listener {
            override fun onPointMoved(mapping: Mapping, newX: Float, newY: Float) {
                params.x = (newX * displayMetrics.widthPixels).toInt()
                params.y = (newY * displayMetrics.heightPixels).toInt()
                windowManager.updateViewLayout(pointView, params)
                persistPosition(mapping)
            }

            override fun onPointDoubleTapped(mapping: Mapping) {
                // No overlay (fora do editor), o duplo toque não abre a
                // edição de tecla para não atrapalhar a jogatina; essa
                // ação fica restrita à EditorActivity.
            }

            override fun onPointSelected(mapping: Mapping) {
                // Reservado para feedback visual futuro (ex.: destacar o
                // botão ao tocar).
            }
        }

        windowManager.addView(pointView, params)
        overlayViews.add(pointView)
    }

    private fun persistPosition(mapping: Mapping) {
        val app = application as MapKeyApplication
        serviceScope.launch {
            app.mappingManager.updateMapping(mapping)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, OverlayMappingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val contentIntent = Intent(this, MainActivity::class.java)
        val contentPendingIntent = PendingIntent.getActivity(
            this, 0, contentIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.activation_notification_title))
            .setContentText(getString(R.string.activation_notification_text))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(contentPendingIntent)
            .addAction(0, getString(R.string.activation_stop), stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.activation_notification_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        overlayViews.forEach { runCatching { windowManager.removeView(it) } }
        overlayViews.clear()
        serviceScope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_PROFILE_ID = "extra_profile_id"
        const val ACTION_STOP = "com.higzent.mapkey.action.STOP_OVERLAY"
        private const val CHANNEL_ID = "mapkey_overlay_channel"
        private const val NOTIFICATION_ID = 1001
    }
}
