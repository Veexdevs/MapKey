package com.higzent.mapkey.storage

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.higzent.mapkey.model.Profile

/**
 * Entidade Room correspondente a [Profile]. Mantida separada do model de
 * domínio para não acoplar as anotações do Room à camada de UI/lógica.
 */
@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    val lastModifiedAt: Long
) {
    fun toDomain(): Profile = Profile(
        id = id,
        name = name,
        createdAt = createdAt,
        lastModifiedAt = lastModifiedAt
    )

    companion object {
        fun fromDomain(profile: Profile): ProfileEntity = ProfileEntity(
            id = profile.id,
            name = profile.name,
            createdAt = profile.createdAt,
            lastModifiedAt = profile.lastModifiedAt
        )
    }
}
