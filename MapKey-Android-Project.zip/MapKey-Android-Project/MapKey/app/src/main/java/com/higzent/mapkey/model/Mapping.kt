package com.higzent.mapkey.model

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * Representa um único ponto de mapeamento: um botão virtual desenhado na
 * tela, associado a uma tecla de teclado ou a uma ação de mouse.
 *
 * As coordenadas [x] e [y] são armazenadas como frações (0f..1f) da área de
 * edição/overlay, e não em pixels absolutos. Isso garante que o mesmo
 * mapeamento funcione corretamente em telas de resoluções diferentes.
 *
 * @property id identificador único do ponto (gerado automaticamente).
 * @property profileId perfil ao qual este ponto pertence.
 * @property label nome de exibição da tecla dentro do botão (ex.: "W", "Espaço").
 * @property keyName nome interno da tecla/ação associada (ex.: "KEYCODE_W", "LEFT_CLICK").
 * @property inputType se a entrada é de teclado ou mouse.
 * @property x posição horizontal relativa (0f = esquerda, 1f = direita).
 * @property y posição vertical relativa (0f = topo, 1f = base).
 * @property sizeDp diâmetro do botão em dp.
 * @property opacity opacidade do botão, de 0f (invisível) a 1f (opaco).
 */
@Serializable
data class Mapping(
    val id: String = UUID.randomUUID().toString(),
    val profileId: String,
    var label: String,
    var keyName: String,
    var inputType: InputType = InputType.KEYBOARD,
    var x: Float,
    var y: Float,
    var sizeDp: Float = DEFAULT_SIZE_DP,
    var opacity: Float = DEFAULT_OPACITY
) {
    companion object {
        const val DEFAULT_SIZE_DP = 64f
        const val MIN_SIZE_DP = 32f
        const val MAX_SIZE_DP = 140f
        const val DEFAULT_OPACITY = 0.85f
    }
}
