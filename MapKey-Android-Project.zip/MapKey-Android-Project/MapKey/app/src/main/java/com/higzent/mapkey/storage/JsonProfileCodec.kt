package com.higzent.mapkey.storage

import com.higzent.mapkey.model.Mapping
import com.higzent.mapkey.model.Profile
import com.higzent.mapkey.model.ProfileExport
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Responsável por serializar/desserializar um [Profile] e seus [Mapping]
 * para um arquivo JSON portátil, permitindo compartilhar ou fazer backup de
 * um perfil de mapeamento fora do banco Room local.
 */
object JsonProfileCodec {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun encode(profile: Profile, mappings: List<Mapping>): String {
        val export = ProfileExport(profile = profile, mappings = mappings)
        return json.encodeToString(export)
    }

    /**
     * Decodifica um JSON exportado anteriormente. Retorna null se o
     * conteúdo estiver malformado, em vez de lançar exceção, para que a UI
     * possa mostrar uma mensagem de erro amigável.
     */
    fun decode(content: String): ProfileExport? {
        return try {
            json.decodeFromString(ProfileExport.serializer(), content)
        } catch (e: Exception) {
            null
        }
    }
}
