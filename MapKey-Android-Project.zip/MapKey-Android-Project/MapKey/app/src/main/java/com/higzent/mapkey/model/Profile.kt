package com.higzent.mapkey.model

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * Representa um perfil de mapeamento, isto é, um conjunto nomeado de pontos
 * de mapeamento (ex.: "Free Fire", "Roblox", "Minecraft", "GTA",
 * "Meu Perfil").
 *
 * O perfil em si não guarda a lista de [Mapping] diretamente — eles são
 * relacionados pelo campo [Mapping.profileId] e consultados através do
 * ProfileManager/MappingManager, seguindo o padrão de relação 1:N usado
 * pelo Room.
 */
@Serializable
data class Profile(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val createdAt: Long = System.currentTimeMillis(),
    var lastModifiedAt: Long = System.currentTimeMillis()
)

/**
 * Estrutura usada exclusivamente para exportação/importação em JSON,
 * agrupando um perfil com todos os seus pontos de mapeamento em um único
 * arquivo portátil.
 */
@Serializable
data class ProfileExport(
    val profile: Profile,
    val mappings: List<Mapping>
)
