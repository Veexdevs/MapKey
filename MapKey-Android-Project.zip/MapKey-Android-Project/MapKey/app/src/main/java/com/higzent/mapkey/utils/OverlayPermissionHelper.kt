package com.higzent.mapkey.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * Helper para verificar e solicitar a permissão SYSTEM_ALERT_WINDOW
 * (exibir sobre outros aplicativos), usando exclusivamente as APIs
 * oficiais Settings.canDrawOverlays() e ACTION_MANAGE_OVERLAY_PERMISSION.
 */
object OverlayPermissionHelper {

    fun hasOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun buildPermissionIntent(context: Context): Intent {
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
    }
}
