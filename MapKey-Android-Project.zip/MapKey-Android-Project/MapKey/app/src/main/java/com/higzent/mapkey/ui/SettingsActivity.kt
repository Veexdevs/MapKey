package com.higzent.mapkey.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.higzent.mapkey.BuildConfig
import com.higzent.mapkey.MapKeyApplication
import com.higzent.mapkey.R
import com.higzent.mapkey.databinding.ActivitySettingsBinding

/**
 * Tela de configurações do MapKey: vibração ao tocar, alinhar à grade, e
 * atalho para a tela de acessibilidade do sistema (para o
 * AccessibilityService opcional).
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val app get() = application as MapKeyApplication

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }

        binding.switchVibration.isChecked = app.settingsManager.vibrationEnabled
        binding.switchGridSnap.isChecked = app.settingsManager.gridSnapEnabled

        binding.switchVibration.setOnCheckedChangeListener { _, isChecked ->
            app.settingsManager.vibrationEnabled = isChecked
        }
        binding.switchGridSnap.setOnCheckedChangeListener { _, isChecked ->
            app.settingsManager.gridSnapEnabled = isChecked
        }

        binding.btnOpenAccessibilitySettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.textVersion.text = getString(R.string.settings_version, BuildConfig.VERSION_NAME)
    }
}
