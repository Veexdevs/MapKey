package com.higzent.mapkey.ui

import android.app.Dialog
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.higzent.mapkey.databinding.DialogKeyPickerBinding
import com.higzent.mapkey.mapping.KeyboardHandler
import com.higzent.mapkey.model.KeyCatalog
import com.higzent.mapkey.model.KeyOption

/**
 * Diálogo de seleção de tecla/ação para um ponto de mapeamento. Mostra o
 * catálogo de teclas iniciais (KeyCatalog) e também escuta eventos de
 * teclado físico enquanto está aberto (via KeyboardHandler), permitindo que
 * o usuário simplesmente pressione a tecla desejada em um teclado
 * conectado, se preferir não escolher da lista.
 */
class KeyPickerDialog(
    private val onKeySelected: (KeyOption) -> Unit
) : DialogFragment() {

    private var _binding: DialogKeyPickerBinding? = null
    private val binding get() = _binding!!

    private val keyboardHandler = KeyboardHandler()

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogKeyPickerBinding.inflate(LayoutInflater.from(requireContext()))

        binding.recyclerKeys.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerKeys.adapter = KeyOptionAdapter(KeyCatalog.all) { option ->
            onKeySelected(option)
            dismiss()
        }

        keyboardHandler.listener = object : KeyboardHandler.Listener {
            override fun onPhysicalKeyDetected(option: KeyOption) {
                binding.textDetectedKey.visibility = android.view.View.VISIBLE
                binding.textDetectedKey.text =
                    getString(com.higzent.mapkey.R.string.editor_physical_key_detected, option.displayName)
                onKeySelected(option)
                dismiss()
            }

            override fun onUnknownKeyDetected(keyCode: Int, keyLabel: String) {
                binding.textDetectedKey.visibility = android.view.View.VISIBLE
                binding.textDetectedKey.text =
                    getString(com.higzent.mapkey.R.string.editor_physical_key_detected, keyLabel)
            }
        }

        return Dialog(requireContext()).apply {
            setContentView(binding.root)
            setOnKeyListener { _, _, event ->
                if (event.action == KeyEvent.ACTION_DOWN) {
                    keyboardHandler.handleKeyEvent(event)
                } else {
                    false
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
