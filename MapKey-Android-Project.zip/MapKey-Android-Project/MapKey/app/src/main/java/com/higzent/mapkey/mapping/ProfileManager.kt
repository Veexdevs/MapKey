package com.higzent.mapkey.mapping

import com.higzent.mapkey.model.Profile
import com.higzent.mapkey.storage.MapKeyDatabase
import com.higzent.mapkey.storage.ProfileEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Gerencia a criação, atualização, exclusão e consulta de [Profile],
 * delegando a persistência ao Room através de [MapKeyDatabase].
 */
class ProfileManager(database: MapKeyDatabase) {

    private val profileDao = database.profileDao()

    fun observeProfiles(): Flow<List<Profile>> =
        profileDao.observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun getAllProfiles(): List<Profile> =
        profileDao.getAll().map { it.toDomain() }

    suspend fun getProfile(id: String): Profile? =
        profileDao.getById(id)?.toDomain()

    suspend fun createProfile(name: String): Profile {
        val profile = Profile(name = name)
        profileDao.insert(ProfileEntity.fromDomain(profile))
        return profile
    }

    suspend fun renameProfile(profile: Profile, newName: String) {
        val updated = profile.copy(name = newName, lastModifiedAt = System.currentTimeMillis())
        profileDao.update(ProfileEntity.fromDomain(updated))
    }

    suspend fun touchProfile(profile: Profile) {
        val updated = profile.copy(lastModifiedAt = System.currentTimeMillis())
        profileDao.update(ProfileEntity.fromDomain(updated))
    }

    suspend fun deleteProfile(profile: Profile) {
        profileDao.delete(ProfileEntity.fromDomain(profile))
    }

    /**
     * Cria os perfis sugeridos na primeira execução do aplicativo
     * (Free Fire, Roblox, Minecraft, GTA, Meu Perfil), caso ainda não
     * existam perfis salvos.
     */
    suspend fun seedDefaultProfilesIfEmpty() {
        if (profileDao.getAll().isNotEmpty()) return
        listOf("Free Fire", "Roblox", "Minecraft", "GTA", "Meu Perfil").forEach { name ->
            createProfile(name)
        }
    }
}
