package com.higzent.mapkey.model

/**
 * Ações de mouse suportadas pelo MapKey.
 *
 * O suporte a mouse físico via USB/Bluetooth é feito através dos eventos
 * MotionEvent com source SOURCE_MOUSE, disponíveis desde a API 23 no
 * Android (View.onGenericMotionEvent / onTouchEvent com
 * MotionEvent.getButtonState()). Veja MouseHandler para a implementação e
 * as limitações documentadas.
 */
enum class MouseAction(val label: String) {
    LEFT_CLICK("Clique esquerdo"),
    RIGHT_CLICK("Clique direito"),
    MOVE("Movimento"),
    SCROLL("Scroll")
}
