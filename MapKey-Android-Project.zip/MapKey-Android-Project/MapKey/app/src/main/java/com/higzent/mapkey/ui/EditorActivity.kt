package com.higzent.mapkey.ui

import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.higzent.mapkey.MapKeyApplication
import com.higzent.mapkey.R
import com.higzent.mapkey.databinding.ActivityEditorBinding
import com.higzent.mapkey.mapping.MappingPointView
import com.higzent.mapkey.model.InputType
import com.higzent.mapkey.model.Mapping
import kotlinx.coroutines.launch

/**
 * Editor visual de mapeamento. Mostra uma área que representa a tela do
 * jogo (editorCanvas) onde o usuário pode adicionar, arrastar, redimensionar,
 * duplicar e excluir pontos de mapeamento, além de escolher a tecla
 * associada a cada um.
 */
class EditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditorBinding
    private val app get() = application as MapKeyApplication

    private lateinit var profileId: String
    private val pointViews = mutableMapOf<String, MappingPointView>()
    private var selectedMapping: Mapping? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileId = intent.getStringExtra(EXTRA_PROFILE_ID) ?: run {
            finish()
            return
        }

        binding.btnBack.setOnClickListener { finish() }
        binding.btnAddPoint.setOnClickListener { addNewPoint() }

        binding.btnChooseKey.setOnClickListener { showKeyPicker() }
        binding.btnDuplicatePoint.setOnClickListener { duplicateSelected() }
        binding.btnDeletePoint.setOnClickListener { confirmDeleteSelected() }

        setupSeekBars()
        loadMappings()
    }

    private fun setupSeekBars() {
        binding.seekOpacity.setOnSeekBarChangeListener(object : SimpleSeekBarListener() {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val mapping = selectedMapping ?: return
                mapping.opacity = (progress / 100f).coerceIn(0.1f, 1f)
                pointViews[mapping.id]?.applyVisualState()
                persist(mapping)
            }
        })

        binding.seekSize.setOnSeekBarChangeListener(object : SimpleSeekBarListener() {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val mapping = selectedMapping ?: return
                val range = Mapping.MAX_SIZE_DP - Mapping.MIN_SIZE_DP
                mapping.sizeDp = Mapping.MIN_SIZE_DP + (range * (progress / 100f))
                pointViews[mapping.id]?.applyVisualState()
                persist(mapping)
            }
        })
    }

    private fun loadMappings() {
        lifecycleScope.launch {
            app.mappingManager.observeMappings(profileId).collect { mappings ->
                // Evita recriar views que já existem; apenas sincroniza o
                // conjunto atual com o que veio do banco.
                val currentIds = mappings.map { it.id }.toSet()

                // Remove views de pontos que não existem mais.
                pointViews.keys.filter { it !in currentIds }.forEach { id ->
                    pointViews[id]?.let { binding.editorCanvas.removeView(it) }
                    pointViews.remove(id)
                }

                mappings.forEach { mapping ->
                    val existing = pointViews[mapping.id]
                    if (existing == null) {
                        addPointView(mapping)
                    }
                }
            }
        }
    }

    private fun addPointView(mapping: Mapping) {
        binding.editorCanvas.post {
            val canvasWidth = binding.editorCanvas.width
            val canvasHeight = binding.editorCanvas.height
            if (canvasWidth == 0 || canvasHeight == 0) return@post

            val pointView = MappingPointView(this, mapping, editable = true)
            pointView.parentWidthPx = canvasWidth
            pointView.parentHeightPx = canvasHeight

            val params = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
            params.gravity = Gravity.TOP or Gravity.START
            binding.editorCanvas.addView(pointView, params)

            pointView.x = mapping.x * canvasWidth
            pointView.y = mapping.y * canvasHeight

            pointView.listener = object : MappingPointView.Listener {
                override fun onPointMoved(mapping: Mapping, newX: Float, newY: Float) {
                    persist(mapping)
                }

                override fun onPointDoubleTapped(mapping: Mapping) {
                    selectPoint(mapping)
                    showKeyPicker()
                }

                override fun onPointSelected(mapping: Mapping) {
                    selectPoint(mapping)
                }
            }

            pointViews[mapping.id] = pointView
        }
    }

    private fun selectPoint(mapping: Mapping) {
        selectedMapping = mapping
        binding.selectedPointToolbar.visibility = android.view.View.VISIBLE
        binding.textSelectedKeyName.text = mapping.label

        val range = Mapping.MAX_SIZE_DP - Mapping.MIN_SIZE_DP
        val sizeProgress = (((mapping.sizeDp - Mapping.MIN_SIZE_DP) / range) * 100f).toInt()
        binding.seekSize.progress = sizeProgress.coerceIn(0, 100)
        binding.seekOpacity.progress = (mapping.opacity * 100f).toInt().coerceIn(0, 100)
    }

    private fun addNewPoint() {
        lifecycleScope.launch {
            app.mappingManager.addMapping(
                profileId = profileId,
                label = "W",
                keyName = "KEYCODE_W",
                inputType = InputType.KEYBOARD,
                x = 0.4f,
                y = 0.4f
            )
        }
    }

    private fun showKeyPicker() {
        val mapping = selectedMapping ?: return
        KeyPickerDialog { option ->
            mapping.label = option.displayName
            mapping.keyName = option.internalName
            mapping.inputType = option.inputType
            pointViews[mapping.id]?.applyVisualState()
            binding.textSelectedKeyName.text = mapping.label
            persist(mapping)
        }.show(supportFragmentManager, "key_picker")
    }

    private fun duplicateSelected() {
        val mapping = selectedMapping ?: return
        lifecycleScope.launch {
            app.mappingManager.duplicateMapping(mapping)
        }
    }

    private fun confirmDeleteSelected() {
        val mapping = selectedMapping ?: return
        AlertDialog.Builder(this)
            .setMessage(R.string.editor_confirm_delete)
            .setPositiveButton(R.string.generic_yes) { _, _ ->
                lifecycleScope.launch {
                    app.mappingManager.deleteMapping(mapping)
                    selectedMapping = null
                    binding.selectedPointToolbar.visibility = android.view.View.GONE
                }
            }
            .setNegativeButton(R.string.generic_no, null)
            .show()
    }

    private fun persist(mapping: Mapping) {
        lifecycleScope.launch {
            app.mappingManager.updateMapping(mapping)
        }
    }

    /** Implementação base vazia para simplificar os listeners de SeekBar. */
    private abstract class SimpleSeekBarListener : android.widget.SeekBar.OnSeekBarChangeListener {
        override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
    }

    companion object {
        const val EXTRA_PROFILE_ID = "extra_profile_id"
        const val EXTRA_PROFILE_NAME = "extra_profile_name"
    }
}
