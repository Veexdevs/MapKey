package com.higzent.mapkey.model

import android.view.KeyEvent

/**
 * Representa uma entrada do catálogo de teclas/ações disponíveis para
 * associar a um ponto de mapeamento.
 *
 * @property displayName nome mostrado ao usuário na interface.
 * @property internalName nome salvo no [Mapping.keyName] (estável entre versões).
 * @property inputType KEYBOARD ou MOUSE.
 * @property androidKeyCode código oficial do Android (KeyEvent.KEYCODE_*),
 *   nulo quando o item é uma ação de mouse.
 */
data class KeyOption(
    val displayName: String,
    val internalName: String,
    val inputType: InputType,
    val androidKeyCode: Int? = null
)

/**
 * Catálogo estático com as teclas e ações iniciais suportadas pelo MapKey,
 * conforme especificado: WASD, Space, Shift, Ctrl, E, F, R, 1-9, e os
 * botões de mouse esquerdo/direito.
 *
 * Os códigos de tecla usados são todos constantes públicas e oficiais da
 * classe android.view.KeyEvent — nenhum valor foi inventado.
 */
object KeyCatalog {

    val keyboardKeys: List<KeyOption> = listOf(
        KeyOption("W", "KEYCODE_W", InputType.KEYBOARD, KeyEvent.KEYCODE_W),
        KeyOption("A", "KEYCODE_A", InputType.KEYBOARD, KeyEvent.KEYCODE_A),
        KeyOption("S", "KEYCODE_S", InputType.KEYBOARD, KeyEvent.KEYCODE_S),
        KeyOption("D", "KEYCODE_D", InputType.KEYBOARD, KeyEvent.KEYCODE_D),
        KeyOption("Space", "KEYCODE_SPACE", InputType.KEYBOARD, KeyEvent.KEYCODE_SPACE),
        KeyOption("Shift", "KEYCODE_SHIFT_LEFT", InputType.KEYBOARD, KeyEvent.KEYCODE_SHIFT_LEFT),
        KeyOption("Ctrl", "KEYCODE_CTRL_LEFT", InputType.KEYBOARD, KeyEvent.KEYCODE_CTRL_LEFT),
        KeyOption("E", "KEYCODE_E", InputType.KEYBOARD, KeyEvent.KEYCODE_E),
        KeyOption("F", "KEYCODE_F", InputType.KEYBOARD, KeyEvent.KEYCODE_F),
        KeyOption("R", "KEYCODE_R", InputType.KEYBOARD, KeyEvent.KEYCODE_R),
        KeyOption("1", "KEYCODE_1", InputType.KEYBOARD, KeyEvent.KEYCODE_1),
        KeyOption("2", "KEYCODE_2", InputType.KEYBOARD, KeyEvent.KEYCODE_2),
        KeyOption("3", "KEYCODE_3", InputType.KEYBOARD, KeyEvent.KEYCODE_3),
        KeyOption("4", "KEYCODE_4", InputType.KEYBOARD, KeyEvent.KEYCODE_4),
        KeyOption("5", "KEYCODE_5", InputType.KEYBOARD, KeyEvent.KEYCODE_5),
        KeyOption("6", "KEYCODE_6", InputType.KEYBOARD, KeyEvent.KEYCODE_6),
        KeyOption("7", "KEYCODE_7", InputType.KEYBOARD, KeyEvent.KEYCODE_7),
        KeyOption("8", "KEYCODE_8", InputType.KEYBOARD, KeyEvent.KEYCODE_8),
        KeyOption("9", "KEYCODE_9", InputType.KEYBOARD, KeyEvent.KEYCODE_9)
    )

    val mouseActions: List<KeyOption> = listOf(
        KeyOption(MouseAction.LEFT_CLICK.label, MouseAction.LEFT_CLICK.name, InputType.MOUSE),
        KeyOption(MouseAction.RIGHT_CLICK.label, MouseAction.RIGHT_CLICK.name, InputType.MOUSE)
    )

    val all: List<KeyOption> = keyboardKeys + mouseActions

    fun findByInternalName(internalName: String): KeyOption? =
        all.firstOrNull { it.internalName == internalName }

    /**
     * Tenta encontrar uma opção de teclado correspondente a um KeyEvent
     * físico recebido pelo Android (usado pelo KeyboardHandler quando um
     * teclado externo está conectado). Se a tecla pressionada não estiver
     * no catálogo inicial, retorna null — o chamador decide se cria uma
     * entrada avulsa com o nome bruto da tecla.
     */
    fun findByKeyCode(keyCode: Int): KeyOption? =
        keyboardKeys.firstOrNull { it.androidKeyCode == keyCode }
}
