package com.higzent.mapkey.mapping

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.higzent.mapkey.R
import com.higzent.mapkey.model.Mapping
import kotlin.math.roundToInt

/**
 * View customizada que representa visualmente um [Mapping] dentro da área
 * de edição (ver EditorActivity) ou dentro do overlay (ver
 * OverlayMappingService).
 *
 * Responsabilidades:
 * - Desenhar o botão circular com o nome da tecla.
 * - Aplicar tamanho e opacidade configurados no [Mapping].
 * - Notificar o listener quando o usuário arrasta, dá duplo toque ou solta
 *   o botão (para persistir a nova posição).
 *
 * Esta view NÃO lida com persistência — apenas notifica callbacks, mantendo
 * a separação de responsabilidades pedida na arquitetura do projeto.
 */
class MappingPointView(
    context: Context,
    var mapping: Mapping,
    private val editable: Boolean = true
) : FrameLayout(context) {

    interface Listener {
        fun onPointMoved(mapping: Mapping, newX: Float, newY: Float)
        fun onPointDoubleTapped(mapping: Mapping)
        fun onPointSelected(mapping: Mapping)
    }

    var listener: Listener? = null

    private val labelView = TextView(context)
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var isDragging = false
    private var lastTapTime = 0L

    /** Referência ao container pai, usada para converter posição em pixels -> fração. */
    var parentWidthPx = 0
    var parentHeightPx = 0

    init {
        labelView.gravity = Gravity.CENTER
        labelView.setTextColor(Color.WHITE)
        labelView.setTypeface(labelView.typeface, android.graphics.Typeface.BOLD)
        labelView.text = mapping.label
        addView(labelView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        applyVisualState()
    }

    fun applyVisualState() {
        val sizePx = dpToPx(mapping.sizeDp)
        layoutParams = layoutParams?.apply {
            width = sizePx
            height = sizePx
        } ?: LayoutParams(sizePx, sizePx)

        val base = ContextCompat.getDrawable(context, R.drawable.shape_mapping_point)?.mutate() as? GradientDrawable
        base?.alpha = (mapping.opacity.coerceIn(0f, 1f) * 255).roundToInt()
        background = base

        labelView.text = mapping.label
        labelView.alpha = mapping.opacity.coerceIn(0.3f, 1f)
        labelView.textSize = (mapping.sizeDp / 3.2f).coerceIn(10f, 28f)

        requestLayout()
        invalidate()
    }

    private fun dpToPx(dp: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics
        ).roundToInt()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!editable) return false

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastRawX = event.rawX
                lastRawY = event.rawY
                isDragging = false
                listener?.onPointSelected(mapping)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastRawX
                val dy = event.rawY - lastRawY

                if (Math.abs(dx) > TOUCH_SLOP || Math.abs(dy) > TOUCH_SLOP) {
                    isDragging = true
                }

                if (isDragging) {
                    val maxLeft = (parentWidthPx - width).coerceAtLeast(0).toFloat()
                    val maxTop = (parentHeightPx - height).coerceAtLeast(0).toFloat()
                    val newLeft = (left + dx).coerceIn(0f, maxLeft)
                    val newTop = (top + dy).coerceIn(0f, maxTop)

                    x = newLeft
                    y = newTop

                    lastRawX = event.rawX
                    lastRawY = event.rawY
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (isDragging) {
                    val fractionX = if (parentWidthPx > 0) x / parentWidthPx else mapping.x
                    val fractionY = if (parentHeightPx > 0) y / parentHeightPx else mapping.y
                    mapping.x = fractionX.coerceIn(0f, 1f)
                    mapping.y = fractionY.coerceIn(0f, 1f)
                    listener?.onPointMoved(mapping, mapping.x, mapping.y)
                } else {
                    val now = System.currentTimeMillis()
                    if (now - lastTapTime < DOUBLE_TAP_MS) {
                        listener?.onPointDoubleTapped(mapping)
                        lastTapTime = 0L
                    } else {
                        lastTapTime = now
                    }
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    companion object {
        private const val TOUCH_SLOP = 6f
        private const val DOUBLE_TAP_MS = 300L
    }
}
