package com.higzent.mapkey.storage

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.higzent.mapkey.model.InputType
import com.higzent.mapkey.model.Mapping

/**
 * Entidade Room correspondente a [Mapping]. A chave estrangeira garante que,
 * ao excluir um perfil, todos os seus pontos de mapeamento sejam removidos
 * em cascata (ver onDelete = CASCADE).
 */
@Entity(
    tableName = "mappings",
    foreignKeys = [
        ForeignKey(
            entity = ProfileEntity::class,
            parentColumns = ["id"],
            childColumns = ["profileId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("profileId")]
)
data class MappingEntity(
    @PrimaryKey val id: String,
    val profileId: String,
    val label: String,
    val keyName: String,
    val inputType: String,
    val x: Float,
    val y: Float,
    val sizeDp: Float,
    val opacity: Float
) {
    fun toDomain(): Mapping = Mapping(
        id = id,
        profileId = profileId,
        label = label,
        keyName = keyName,
        inputType = InputType.valueOf(inputType),
        x = x,
        y = y,
        sizeDp = sizeDp,
        opacity = opacity
    )

    companion object {
        fun fromDomain(mapping: Mapping): MappingEntity = MappingEntity(
            id = mapping.id,
            profileId = mapping.profileId,
            label = mapping.label,
            keyName = mapping.keyName,
            inputType = mapping.inputType.name,
            x = mapping.x,
            y = mapping.y,
            sizeDp = mapping.sizeDp,
            opacity = mapping.opacity
        )
    }
}
