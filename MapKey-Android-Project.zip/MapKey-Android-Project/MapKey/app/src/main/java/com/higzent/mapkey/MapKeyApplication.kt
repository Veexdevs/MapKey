package com.higzent.mapkey

import android.app.Application
import com.higzent.mapkey.mapping.MappingManager
import com.higzent.mapkey.mapping.ProfileManager
import com.higzent.mapkey.storage.MapKeyDatabase
import com.higzent.mapkey.utils.SettingsManager

/**
 * Classe Application do MapKey. Centraliza a criação de instâncias
 * compartilhadas (banco de dados e managers) para evitar duplicidade entre
 * as Activities, seguindo um padrão simples de injeção manual de
 * dependências (sem necessidade de bibliotecas externas de DI).
 */
class MapKeyApplication : Application() {

    lateinit var database: MapKeyDatabase
        private set

    lateinit var profileManager: ProfileManager
        private set

    lateinit var mappingManager: MappingManager
        private set

    lateinit var settingsManager: SettingsManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = MapKeyDatabase.getInstance(this)
        profileManager = ProfileManager(database)
        mappingManager = MappingManager(database)
        settingsManager = SettingsManager(this)
    }
}
