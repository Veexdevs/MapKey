package com.higzent.mapkey.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.higzent.mapkey.MapKeyApplication
import com.higzent.mapkey.R
import com.higzent.mapkey.databinding.ActivityActivationBinding
import com.higzent.mapkey.model.Profile
import com.higzent.mapkey.service.OverlayMappingService
import com.higzent.mapkey.utils.OverlayPermissionHelper
import kotlinx.coroutines.launch

/**
 * Tela de preparação e controle do modo de mapeamento (overlay). Permite
 * escolher o perfil a ativar e iniciar/parar o OverlayMappingService.
 *
 * Antes de iniciar o overlay, verifica se a permissão SYSTEM_ALERT_WINDOW
 * já foi concedida; caso não, encaminha o usuário para PermissionsActivity.
 */
class ActivationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityActivationBinding
    private val app get() = application as MapKeyApplication

    private var profiles: List<Profile> = emptyList()
    private var isOverlayActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityActivationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnToggleOverlay.setOnClickListener { toggleOverlay() }

        lifecycleScope.launch {
            profiles = app.profileManager.getAllProfiles()
            val names = profiles.map { it.name }
            binding.spinnerProfiles.adapter = ArrayAdapter(
                this@ActivationActivity,
                android.R.layout.simple_spinner_dropdown_item,
                names
            )

            val preselectId = intent.getStringExtra(EXTRA_PROFILE_ID)
            val preselectIndex = profiles.indexOfFirst { it.id == preselectId }
            if (preselectIndex >= 0) {
                binding.spinnerProfiles.setSelection(preselectIndex)
            }
        }
    }

    private fun toggleOverlay() {
        if (isOverlayActive) {
            stopOverlay()
            return
        }

        if (!OverlayPermissionHelper.hasOverlayPermission(this)) {
            startActivity(Intent(this, PermissionsActivity::class.java))
            return
        }

        val selectedIndex = binding.spinnerProfiles.selectedItemPosition
        val profile = profiles.getOrNull(selectedIndex) ?: return

        val serviceIntent = Intent(this, OverlayMappingService::class.java)
        serviceIntent.putExtra(OverlayMappingService.EXTRA_PROFILE_ID, profile.id)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        isOverlayActive = true
        binding.btnToggleOverlay.text = getString(R.string.activation_stop)
    }

    private fun stopOverlay() {
        val stopIntent = Intent(this, OverlayMappingService::class.java)
        stopIntent.action = OverlayMappingService.ACTION_STOP
        startService(stopIntent)

        isOverlayActive = false
        binding.btnToggleOverlay.text = getString(R.string.activation_start)
    }

    companion object {
        const val EXTRA_PROFILE_ID = "extra_profile_id"
    }
}
