package com.higzent.mapkey.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.higzent.mapkey.MapKeyApplication
import com.higzent.mapkey.databinding.ActivityMainBinding
import com.higzent.mapkey.model.Profile
import kotlinx.coroutines.launch

/**
 * Tela principal do MapKey. Mostra o perfil ativo, a quantidade de teclas
 * configuradas nele, e os atalhos para as demais telas do app.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val app get() = application as MapKeyApplication

    private var currentProfile: Profile? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnNewMapping.setOnClickListener { openEditorForCurrentOrNewProfile() }
        binding.btnEditMapping.setOnClickListener { openEditorForCurrentOrNewProfile() }
        binding.btnSaveProfile.setOnClickListener { startActivity(Intent(this, ProfileListActivity::class.java)) }
        binding.btnLoadProfile.setOnClickListener { startActivity(Intent(this, ProfileListActivity::class.java)) }
        binding.btnActivateMapping.setOnClickListener { openActivation() }
        binding.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }

        lifecycleScope.launch {
            app.profileManager.seedDefaultProfilesIfEmpty()
            loadCurrentProfile()
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch { loadCurrentProfile() }
    }

    private suspend fun loadCurrentProfile() {
        val lastId = app.settingsManager.lastActiveProfileId
        val profiles = app.profileManager.getAllProfiles()

        val profile = profiles.firstOrNull { it.id == lastId } ?: profiles.firstOrNull()
        currentProfile = profile

        if (profile == null) {
            binding.textCurrentProfile.text = getString(
                com.higzent.mapkey.R.string.main_current_profile,
                getString(com.higzent.mapkey.R.string.generic_no_profile)
            )
            binding.textKeysConfigured.text = getString(com.higzent.mapkey.R.string.main_keys_configured, 0)
            return
        }

        app.settingsManager.lastActiveProfileId = profile.id
        binding.textCurrentProfile.text =
            getString(com.higzent.mapkey.R.string.main_current_profile, profile.name)

        val mappings = app.mappingManager.getMappings(profile.id)
        binding.textKeysConfigured.text =
            getString(com.higzent.mapkey.R.string.main_keys_configured, mappings.size)
    }

    private fun openEditorForCurrentOrNewProfile() {
        val profile = currentProfile
        if (profile == null) {
            startActivity(Intent(this, ProfileListActivity::class.java))
            return
        }
        val intent = Intent(this, EditorActivity::class.java)
        intent.putExtra(EditorActivity.EXTRA_PROFILE_ID, profile.id)
        intent.putExtra(EditorActivity.EXTRA_PROFILE_NAME, profile.name)
        startActivity(intent)
    }

    private fun openActivation() {
        val profile = currentProfile
        val intent = Intent(this, ActivationActivity::class.java)
        profile?.let { intent.putExtra(ActivationActivity.EXTRA_PROFILE_ID, it.id) }
        startActivity(intent)
    }
}
