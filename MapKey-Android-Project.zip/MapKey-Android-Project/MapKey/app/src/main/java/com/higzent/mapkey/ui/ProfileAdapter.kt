package com.higzent.mapkey.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.higzent.mapkey.databinding.ItemProfileBinding
import com.higzent.mapkey.model.Profile

/**
 * Adapter simples para exibir a lista de [Profile] em ProfileListActivity.
 * A contagem de teclas por perfil é fornecida externamente através de
 * [keyCountProvider], pois cada perfil pode ter uma contagem diferente e
 * consultá-la é responsabilidade da Activity (que já observa o banco).
 */
class ProfileAdapter(
    private val onLoad: (Profile) -> Unit,
    private val onDelete: (Profile) -> Unit,
    private val keyCountProvider: (Profile) -> Int
) : RecyclerView.Adapter<ProfileAdapter.ProfileViewHolder>() {

    private val items = mutableListOf<Profile>()

    fun submitList(newItems: List<Profile>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileViewHolder {
        val binding = ItemProfileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProfileViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProfileViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class ProfileViewHolder(private val binding: ItemProfileBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(profile: Profile) {
            binding.textProfileName.text = profile.name
            val count = keyCountProvider(profile)
            binding.textProfileMeta.text = "$count teclas configuradas"

            binding.btnLoadThisProfile.setOnClickListener { onLoad(profile) }
            binding.btnDeleteProfile.setOnClickListener { onDelete(profile) }
        }
    }
}
