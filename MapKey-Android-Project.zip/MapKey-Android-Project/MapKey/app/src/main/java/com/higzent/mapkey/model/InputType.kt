package com.higzent.mapkey.model

/**
 * Representa a origem da entrada associada a um ponto de mapeamento.
 * Usado para diferenciar teclas de teclado físico de botões de mouse,
 * já que cada um é tratado por um handler diferente (ver KeyboardHandler
 * e MouseHandler).
 */
enum class InputType {
    KEYBOARD,
    MOUSE
}
