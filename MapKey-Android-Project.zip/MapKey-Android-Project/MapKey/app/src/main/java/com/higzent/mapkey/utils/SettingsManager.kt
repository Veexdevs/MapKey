package com.higzent.mapkey.utils

import android.content.Context
import android.content.SharedPreferences

/**
 * Gerencia as preferências simples do MapKey (vibração ao tocar, alinhar à
 * grade, último perfil ativo), persistidas via SharedPreferences.
 */
class SettingsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var vibrationEnabled: Boolean
        get() = prefs.getBoolean(KEY_VIBRATION, true)
        set(value) = prefs.edit().putBoolean(KEY_VIBRATION, value).apply()

    var gridSnapEnabled: Boolean
        get() = prefs.getBoolean(KEY_GRID_SNAP, false)
        set(value) = prefs.edit().putBoolean(KEY_GRID_SNAP, value).apply()

    var lastActiveProfileId: String?
        get() = prefs.getString(KEY_LAST_PROFILE, null)
        set(value) = prefs.edit().putString(KEY_LAST_PROFILE, value).apply()

    companion object {
        private const val PREFS_NAME = "mapkey_settings"
        private const val KEY_VIBRATION = "vibration_enabled"
        private const val KEY_GRID_SNAP = "grid_snap_enabled"
        private const val KEY_LAST_PROFILE = "last_active_profile_id"
    }
}
