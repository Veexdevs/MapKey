package com.higzent.mapkey.storage

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MappingDao {

    @Query("SELECT * FROM mappings WHERE profileId = :profileId")
    fun observeByProfile(profileId: String): Flow<List<MappingEntity>>

    @Query("SELECT * FROM mappings WHERE profileId = :profileId")
    suspend fun getByProfile(profileId: String): List<MappingEntity>

    @Query("SELECT COUNT(*) FROM mappings WHERE profileId = :profileId")
    fun observeCountByProfile(profileId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(mapping: MappingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(mappings: List<MappingEntity>)

    @Update
    suspend fun update(mapping: MappingEntity)

    @Delete
    suspend fun delete(mapping: MappingEntity)

    @Query("DELETE FROM mappings WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM mappings WHERE profileId = :profileId")
    suspend fun deleteAllByProfile(profileId: String)
}
