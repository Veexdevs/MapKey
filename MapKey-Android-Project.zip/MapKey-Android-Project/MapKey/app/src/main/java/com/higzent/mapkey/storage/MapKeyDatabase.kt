package com.higzent.mapkey.storage

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Banco de dados local do MapKey. Armazena perfis e seus respectivos pontos
 * de mapeamento. Usa uma única instância (singleton) por processo,
 * conforme recomendado pela documentação do Room.
 */
@Database(
    entities = [ProfileEntity::class, MappingEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MapKeyDatabase : RoomDatabase() {

    abstract fun profileDao(): ProfileDao
    abstract fun mappingDao(): MappingDao

    companion object {
        private const val DATABASE_NAME = "mapkey.db"

        @Volatile
        private var instance: MapKeyDatabase? = null

        fun getInstance(context: Context): MapKeyDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    MapKeyDatabase::class.java,
                    DATABASE_NAME
                ).build().also { instance = it }
            }
        }
    }
}
