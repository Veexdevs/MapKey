package com.higzent.mapkey.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.higzent.mapkey.databinding.ItemKeyOptionBinding
import com.higzent.mapkey.model.InputType
import com.higzent.mapkey.model.KeyOption

/**
 * Adapter para a lista de teclas/ações disponíveis no diálogo de seleção
 * (ver KeyPickerDialog / EditorActivity).
 */
class KeyOptionAdapter(
    private val options: List<KeyOption>,
    private val onSelected: (KeyOption) -> Unit
) : RecyclerView.Adapter<KeyOptionAdapter.KeyOptionViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KeyOptionViewHolder {
        val binding = ItemKeyOptionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return KeyOptionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: KeyOptionViewHolder, position: Int) {
        holder.bind(options[position])
    }

    override fun getItemCount(): Int = options.size

    inner class KeyOptionViewHolder(private val binding: ItemKeyOptionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(option: KeyOption) {
            binding.textKeyDisplayName.text = option.displayName
            binding.textKeyType.text = if (option.inputType == InputType.KEYBOARD) "Teclado" else "Mouse"
            binding.itemKeyRoot.setOnClickListener { onSelected(option) }
        }
    }
}
