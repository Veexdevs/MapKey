package com.higzent.mapkey.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.higzent.mapkey.R
import com.higzent.mapkey.databinding.ActivityPermissionsBinding
import com.higzent.mapkey.utils.OverlayPermissionHelper

/**
 * Tela que explica por que o MapKey precisa da permissão de overlay
 * (exibir sobre outros aplicativos) antes de solicitá-la, conforme pedido
 * na especificação do projeto.
 */
class PermissionsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnGrantOverlay.setOnClickListener {
            startActivity(OverlayPermissionHelper.buildPermissionIntent(this))
        }

        binding.btnContinue.setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val granted = OverlayPermissionHelper.hasOverlayPermission(this)
        binding.textOverlayStatus.text = getString(
            if (granted) R.string.permissions_status_granted else R.string.permissions_status_denied
        )
        binding.textOverlayStatus.setTextColor(
            getColor(if (granted) R.color.mk_success else R.color.mk_danger)
        )
        binding.btnGrantOverlay.isEnabled = !granted
    }
}
