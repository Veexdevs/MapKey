package com.higzent.mapkey.mapping

import android.view.InputDevice
import android.view.MotionEvent
import com.higzent.mapkey.model.MouseAction

/**
 * Responsável por interpretar eventos de mouse físico (USB ou Bluetooth)
 * usando as APIs oficiais do Android, através de MotionEvent com
 * source == InputDevice.SOURCE_MOUSE.
 *
 * Suporte implementado nesta versão:
 * - Detecção de clique esquerdo/direito via MotionEvent.getButtonState().
 * - Detecção de movimento do cursor via ACTION_HOVER_MOVE / ACTION_MOVE.
 * - Detecção de scroll via MotionEvent.AXIS_VSCROLL (getAxisValue).
 *
 * LIMITAÇÃO IMPORTANTE:
 * O Android entrega esses eventos apenas para a View/Activity que está em
 * foco dentro do próprio processo do MapKey. Não é possível, usando APIs
 * públicas, capturar globalmente o mouse do sistema enquanto outro
 * aplicativo está em primeiro plano — isso exigiria privilégios de
 * sistema/root que o MapKey deliberadamente não utiliza.
 */
class MouseHandler {

    interface Listener {
        fun onMouseAction(action: MouseAction, x: Float, y: Float)
    }

    var listener: Listener? = null

    fun isMouseEvent(event: MotionEvent): Boolean {
        val device = InputDevice.getDevice(event.deviceId) ?: return false
        return device.sources and InputDevice.SOURCE_MOUSE == InputDevice.SOURCE_MOUSE
    }

    fun handleMotionEvent(event: MotionEvent): Boolean {
        if (!isMouseEvent(event)) return false

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val isRightClick = (event.buttonState and MotionEvent.BUTTON_SECONDARY) != 0
                val action = if (isRightClick) MouseAction.RIGHT_CLICK else MouseAction.LEFT_CLICK
                listener?.onMouseAction(action, event.x, event.y)
                return true
            }

            MotionEvent.ACTION_HOVER_MOVE, MotionEvent.ACTION_MOVE -> {
                listener?.onMouseAction(MouseAction.MOVE, event.x, event.y)
                return true
            }

            MotionEvent.ACTION_SCROLL -> {
                listener?.onMouseAction(MouseAction.SCROLL, event.x, event.y)
                return true
            }
        }
        return false
    }
}
