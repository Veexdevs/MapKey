package com.higzent.mapkey.mapping

import com.higzent.mapkey.model.InputType
import com.higzent.mapkey.model.Mapping
import com.higzent.mapkey.storage.MapKeyDatabase
import com.higzent.mapkey.storage.MappingEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Gerencia a criação, atualização, exclusão e consulta de [Mapping] dentro
 * de um perfil, delegando a persistência ao Room.
 */
class MappingManager(database: MapKeyDatabase) {

    private val mappingDao = database.mappingDao()

    fun observeMappings(profileId: String): Flow<List<Mapping>> =
        mappingDao.observeByProfile(profileId).map { list -> list.map { it.toDomain() } }

    fun observeCount(profileId: String): Flow<Int> =
        mappingDao.observeCountByProfile(profileId)

    suspend fun getMappings(profileId: String): List<Mapping> =
        mappingDao.getByProfile(profileId).map { it.toDomain() }

    suspend fun addMapping(
        profileId: String,
        label: String,
        keyName: String,
        inputType: InputType,
        x: Float,
        y: Float
    ): Mapping {
        val mapping = Mapping(
            profileId = profileId,
            label = label,
            keyName = keyName,
            inputType = inputType,
            x = x,
            y = y
        )
        mappingDao.insert(MappingEntity.fromDomain(mapping))
        return mapping
    }

    suspend fun updateMapping(mapping: Mapping) {
        mappingDao.update(MappingEntity.fromDomain(mapping))
    }

    suspend fun duplicateMapping(mapping: Mapping): Mapping {
        val copy = mapping.copy(
            id = java.util.UUID.randomUUID().toString(),
            x = (mapping.x + 0.05f).coerceIn(0f, 1f),
            y = (mapping.y + 0.05f).coerceIn(0f, 1f)
        )
        mappingDao.insert(MappingEntity.fromDomain(copy))
        return copy
    }

    suspend fun deleteMapping(mapping: Mapping) {
        mappingDao.deleteById(mapping.id)
    }

    suspend fun replaceAllForProfile(profileId: String, mappings: List<Mapping>) {
        mappingDao.deleteAllByProfile(profileId)
        mappingDao.insertAll(mappings.map { MappingEntity.fromDomain(it) })
    }
}
