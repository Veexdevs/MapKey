package com.higzent.mapkey.ui

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.higzent.mapkey.MapKeyApplication
import com.higzent.mapkey.R
import com.higzent.mapkey.databinding.ActivityProfileListBinding
import com.higzent.mapkey.model.Profile
import kotlinx.coroutines.launch

/**
 * Tela de gerenciamento de perfis: listar, criar, excluir e definir o
 * perfil ativo (usado pela MainActivity e pela EditorActivity).
 */
class ProfileListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileListBinding
    private val app get() = application as MapKeyApplication

    private lateinit var adapter: ProfileAdapter
    private var keyCounts = mutableMapOf<String, Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }

        adapter = ProfileAdapter(
            onLoad = { profile -> selectProfile(profile) },
            onDelete = { profile -> confirmDelete(profile) },
            keyCountProvider = { profile -> keyCounts[profile.id] ?: 0 }
        )
        binding.recyclerProfiles.layoutManager = LinearLayoutManager(this)
        binding.recyclerProfiles.adapter = adapter

        binding.btnCreateProfile.setOnClickListener { createProfile() }

        lifecycleScope.launch {
            app.profileManager.observeProfiles().collect { profiles ->
                refreshKeyCounts(profiles)
                adapter.submitList(profiles)
                binding.textEmptyState.visibility =
                    if (profiles.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            }
        }
    }

    private suspend fun refreshKeyCounts(profiles: List<Profile>) {
        val counts = mutableMapOf<String, Int>()
        profiles.forEach { profile ->
            counts[profile.id] = app.mappingManager.getMappings(profile.id).size
        }
        keyCounts = counts
    }

    private fun createProfile() {
        val name = binding.editNewProfileName.text.toString().trim()
        if (name.isEmpty()) return

        lifecycleScope.launch {
            app.profileManager.createProfile(name)
            binding.editNewProfileName.setText("")
        }
    }

    private fun selectProfile(profile: Profile) {
        app.settingsManager.lastActiveProfileId = profile.id
        finish()
    }

    private fun confirmDelete(profile: Profile) {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.profile_delete_confirm, profile.name))
            .setPositiveButton(R.string.generic_yes) { _, _ ->
                lifecycleScope.launch { app.profileManager.deleteProfile(profile) }
            }
            .setNegativeButton(R.string.generic_no, null)
            .show()
    }
}
