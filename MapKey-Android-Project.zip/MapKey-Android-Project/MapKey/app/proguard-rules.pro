# Regras padrão do ProGuard para o MapKey.
# Mantemos as regras padrão geradas pelo Android Studio.
-keepattributes *Annotation*
