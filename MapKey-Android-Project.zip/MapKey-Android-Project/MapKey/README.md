# MapKey

Mapeador de teclas para jogos — mapeie botões virtuais na tela e associe
teclas de teclado/mouse a posições específicas. Identidade visual própria
(fundo escuro + azul neon), desenvolvido em Kotlin nativo para Android.

Pacote: `com.higzent.mapkey`

---

## 1. Estrutura do projeto

```
app/
├── src/main/java/com/higzent/mapkey/
│   ├── ui/         → Activities, Adapters, Dialogs (tela principal, editor, perfis, etc.)
│   ├── mapping/     → Lógica de mapeamento (ProfileManager, MappingManager, MappingPointView, KeyboardHandler, MouseHandler)
│   ├── model/       → Classes de dados (Mapping, Profile, KeyCatalog, InputType, MouseAction)
│   ├── storage/     → Room (DAOs, entidades, banco) e JsonProfileCodec (export/import)
│   ├── service/     → OverlayMappingService (overlay em primeiro plano) e MapKeyAccessibilityService (opcional)
│   └── utils/       → SettingsManager, OverlayPermissionHelper
├── src/main/res/    → Layouts XML, drawables, cores, strings (tudo em pt-BR)
└── src/main/AndroidManifest.xml
```

- **Min SDK:** 26 (Android 8.0) — necessário para `TYPE_APPLICATION_OVERLAY`
- **Target SDK:** 34
- **Linguagem:** 100% Kotlin
- **Persistência:** Room (SQLite) + exportação/importação em JSON
- **UI:** Views XML tradicionais (não Compose), com Material Components

---

## 2. Como abrir o projeto

### Opção recomendada: Android Studio

1. Baixe e instale o [Android Studio](https://developer.android.com/studio) (versão Iguana/2024.x ou mais recente).
2. Abra o Android Studio → **File > Open** → selecione a pasta raiz `MapKey/` (a que contém `settings.gradle.kts`).
3. Aguarde a sincronização automática do Gradle (o Android Studio baixa o Gradle Wrapper correto e todas as dependências automaticamente na primeira sincronização, pois o projeto já traz `gradle/wrapper/gradle-wrapper.properties` apontando para a versão 8.7).
4. Se o Android Studio pedir para instalar algum componente do SDK (Platform 34, Build-Tools), aceite — ele resolve isso automaticamente.

> **Observação sobre o `gradle-wrapper.jar`:** este pacote inclui os scripts `gradlew`/`gradlew.bat` e o arquivo `gradle-wrapper.properties`, mas **não inclui o binário `gradle-wrapper.jar`** (ele não pôde ser baixado no ambiente onde este projeto foi gerado, por não haver acesso à internet). O Android Studio gera esse arquivo automaticamente ao sincronizar o projeto pela primeira vez. Se você preferir compilar por linha de comando sem abrir o Android Studio antes, rode uma vez:
> ```bash
> gradle wrapper --gradle-version 8.7
> ```
> (usando uma instalação local do Gradle) para gerar o `gradle-wrapper.jar` antes de usar `./gradlew`.

### Opção alternativa: linha de comando

Com o Android SDK e uma instalação de Gradle configurados no `PATH`:

```bash
cd MapKey
gradle wrapper --gradle-version 8.7   # gera o gradle-wrapper.jar, se ainda não existir
./gradlew assembleDebug
```

---

## 3. Compilar o APK

### Pelo Android Studio

1. Com o projeto sincronizado, vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
2. Aguarde a compilação. Ao final, uma notificação "APK(s) generated successfully" aparecerá com um link **locate** — clique para abrir a pasta do APK.
3. O arquivo gerado estará em:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

### Pela linha de comando

```bash
./gradlew assembleDebug
```

O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Para gerar uma versão **release** (não assinada por padrão):

```bash
./gradlew assembleRelease
```

Isso produzirá `app/build/outputs/apk/release/app-release-unsigned.apk`, que precisa ser assinado antes de ser instalado em um dispositivo (ver documentação oficial do Android sobre [assinatura de app](https://developer.android.com/studio/publish/app-signing)) — para testes, use a versão `debug`, que já é assinada automaticamente com uma chave de depuração.

---

## 4. Instalar o APK no celular

### Opção A — Direto do Android Studio (mais simples)

1. Conecte o celular Android via USB com a **depuração USB** ativada (Configurações > Sobre o telefone > toque 7x em "Número da versão" para ativar Opções do desenvolvedor > Depuração USB).
2. No Android Studio, clique no botão verde **Run ▶** (ou `Shift+F10`).
3. Selecione seu dispositivo na lista e aguarde a instalação automática.

### Opção B — Instalar o APK manualmente

1. Copie o arquivo `app-debug.apk` para o celular (via cabo USB, Google Drive, etc.).
2. No celular, permita "Instalar apps de fontes desconhecidas" para o app usado para abrir o APK (Gerenciador de Arquivos, navegador, etc.) — isso é pedido automaticamente na primeira instalação.
3. Toque no arquivo `.apk` no celular e confirme a instalação.

### Opção C — Via ADB

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## 5. Primeira execução e uso

1. Ao abrir o MapKey, perfis padrão são criados automaticamente (Free Fire, Roblox, Minecraft, GTA, Meu Perfil).
2. Toque em **Novo Mapeamento** para abrir o editor do perfil ativo.
3. No editor, toque em **Adicionar Ponto** para criar um botão de tecla (W, por padrão). Arraste-o para a posição desejada.
4. Toque duas vezes no botão (ou use o menu inferior) para escolher a tecla/ação associada, ajustar tamanho e opacidade, duplicar ou excluir.
5. Para ativar o overlay sobre outro app, toque em **Ativar Mapeamento** na tela principal. Na primeira vez, o app pedirá a permissão **"Exibir sobre outros aplicativos"** — conceda-a nas Configurações do sistema que serão abertas automaticamente.
6. Com a permissão concedida, toque em **Iniciar Overlay**. Os botões do perfil selecionado aparecerão sobre qualquer outro app até que você toque em **Parar Overlay** (pelo app ou pela notificação persistente).

---

## 6. Limitações importantes do Android (leia antes de usar)

Este projeto foi construído **apenas com APIs públicas e oficiais do Android**, sem contornar sandbox, permissões ou proteções do sistema. Isso implica limitações reais que fazem parte do design do MapKey, não bugs:

- **O overlay não injeta toques automaticamente dentro do jogo.** Por padrão, tocar em um botão do overlay é uma ação local do MapKey (mover o botão, vibrar, etc.). Para que um toque no botão vire de fato um toque simulado dentro do jogo, é necessário habilitar manualmente o **Serviço de Acessibilidade opcional** do MapKey em Configurações > Acessibilidade — e mesmo assim, a API `dispatchGesture()` simula apenas gestos de toque na tela, nunca eventos de teclado (`KeyEvent`) dentro do processo de outro app.
- **Não há leitura do conteúdo de outros aplicativos.** O `MapKeyAccessibilityService` tem `canRetrieveWindowContent` desabilitado propositalmente — o MapKey não lê nem analisa a tela de outros apps.
- **A automação de toques pode violar os termos de uso de alguns jogos** (sistemas anti-cheat). O uso dessa funcionalidade opcional é de responsabilidade do usuário final.
- Essas decisões e limitações estão documentadas diretamente nos comentários do código-fonte, principalmente em `OverlayMappingService.kt`, `MapKeyAccessibilityService.kt` e `accessibility_service_config.xml`.

---

## 7. Permissões solicitadas

| Permissão | Motivo |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Desenhar os botões de mapeamento sobre outros aplicativos (overlay) |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_SPECIAL_USE` | Manter o overlay ativo de forma confiável com notificação persistente |
| `VIBRATE` | Feedback tátil opcional ao tocar nos botões |
| Acessibilidade (opcional, ativada manualmente) | Base para automação de toques via `dispatchGesture()` no futuro |

Nenhuma permissão de câmera, microfone, contatos, localização ou armazenamento externo é solicitada.
